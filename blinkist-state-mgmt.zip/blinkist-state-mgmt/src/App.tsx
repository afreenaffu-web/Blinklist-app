
import './App.css';

//import image from './components/atoms/Images/book.png'
import AllTabs from './components/molecules/AllTabs';
//import BookCard from './components/molecules/BookCard';

function App() {
  return (
   
    <div className="App" >
    <AllTabs searchTerm='' />  </div>
   
  );
}

export default App;
